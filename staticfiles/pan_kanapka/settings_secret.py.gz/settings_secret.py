# SECURITY WARNING: keep the secret key used in production secret!
import os

# SECRET_KEY = '%i3#+qwmj)3adri14@obu4q!5m263%aa(xv_n#7k)8=5f7fezx'

# PUSH_NOTIFICATIONS_SETTINGS = {
#     "FCM_API_KEY": "AAAAoXwMskU:APA91bGIFjGVmx2FTcj1pouUTi4NgYpaEbq6nq9jN4Mrk5A7vAAMG8oPVjd-QES3pd8Lw7ZLPBgvHUor1yyLhPmChEeSDZa_b6CC2ZvL8NDMzx7YDR1O4hl8x4Zsieokz0mQhqZUMDKO",
#     "GCM_API_KEY": "AAAAoXwMskU:APA91bGIFjGVmx2FTcj1pouUTi4NgYpaEbq6nq9jN4Mrk5A7vAAMG8oPVjd-QES3pd8Lw7ZLPBgvHUor1yyLhPmChEeSDZa_b6CC2ZvL8NDMzx7YDR1O4hl8x4Zsieokz0mQhqZUMDKO",
#     "APNS_CERTIFICATE": "/path/to/your/certificate.pem",
#     "UPDATE_ON_DUPLICATE_REG_ID": True,
#     "UNIQUE_REG_ID": True,
#     "APNS_TOPIC": "com.example.push_test",
#     "WNS_PACKAGE_SECURITY_ID": "[your package security id, e.g: 'ms-app://e-3-4-6234...']",
#     "WNS_SECRET_KEY": "[your app secret key, e.g.: 'KDiejnLKDUWodsjmewuSZkk']",
#     "WP_PRIVATE_KEY": os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "private_key.pem"),
#     "WP_CLAIMS": {'sub': "mailto: jundymek@gmail.com"}
# }

# EMAIL_HOST = 'mail12.mydevil.net'
# EMAIL_PORT = 25
# EMAIL_HOST_USER = 'administracja@netnet24.eu'
# EMAIL_ADDRESS = 'administracja@netnet24.eu'
# EMAIL_HOST_PASSWORD = 'ebDwM7sM'
#
# TO_EMAIL = 'jundymek@gmail.com'

# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.postgresql_psycopg2',
#         'NAME': 'pan_kanapka',
#         'USER': 'admin',
#         'PASSWORD': 'password',
#         'HOST': 'localhost',
#         'PORT': '',
#     }
# }